.. _qdma_global_port_descriptions:

QDMA Global Port Descriptions
-----------------------------
.. image:: table_images/001_qdma_global_port_descriptions.png
    :align: center



.. _axi4_memory_mapped_master_bridge_read_address_interface_port_descriptions:

AXI4 Memory Mapped Master Bridge Read Address Interface Port Descriptions
-------------------------------------------------------------------------
.. image:: table_images/002_axi4_memory_mapped_master_bridge_read_address_interface_port_descriptions.png
    :align: center



.. _axi4_memory_mapped_master_bridge_read_interface_port_descriptions:

AXI4 Memory Mapped Master Bridge Read Interface Port Descriptions
-----------------------------------------------------------------
.. image:: table_images/003_axi4_memory_mapped_master_bridge_read_interface_port_descriptions.png
    :align: center



.. _axi4_memory_mapped_master_bridge_write_address_interface_port_descriptions:

AXI4 Memory Mapped Master Bridge Write Address Interface Port Descriptions
--------------------------------------------------------------------------
.. image:: table_images/004_axi4_memory_mapped_master_bridge_write_address_interface_port_descriptions.png
    :align: center



.. _axi4_memory_mapped_master_bridge_write_interface_port_descriptions:

AXI4 Memory Mapped Master Bridge Write Interface Port Descriptions
------------------------------------------------------------------
.. image:: table_images/005_axi4_memory_mapped_master_bridge_write_interface_port_descriptions.png
    :align: center



.. _axi4_memory_mapped_master_bridge_write_response_interface_port_descriptions:

AXI4 Memory Mapped Master Bridge Write Response Interface Port Descriptions
---------------------------------------------------------------------------
.. image:: table_images/006_axi4_memory_mapped_master_bridge_write_response_interface_port_descriptions.png
    :align: center



.. _axi4_bridge_slave_write_address_interface_port_descriptions:

AXI4 Bridge Slave Write Address Interface Port Descriptions
-----------------------------------------------------------
.. image:: table_images/007_axi4_bridge_slave_write_address_interface_port_descriptions.png
    :align: center



.. _axi4_bridge_slave_write_interface_port_descriptions:

AXI4 Bridge Slave Write Interface Port Descriptions
---------------------------------------------------
.. image:: table_images/008_axi4_bridge_slave_write_interface_port_descriptions.png
    :align: center



.. _axi4_bridge_slave_write_response_interface_port_descriptions:

AXI4 Bridge Slave Write Response Interface Port Descriptions
------------------------------------------------------------
.. image:: table_images/009_axi4_bridge_slave_write_response_interface_port_descriptions.png
    :align: center



.. _axi4_bridge_slave_read_address_interface_port_descriptions:

AXI4 Bridge Slave Read Address Interface Port Descriptions
----------------------------------------------------------
.. image:: table_images/010_axi4_bridge_slave_read_address_interface_port_descriptions.png
    :align: center



.. _axi4_bridge_slave_read_interface_port_descriptions:

AXI4 Bridge Slave Read Interface Port Descriptions
--------------------------------------------------
.. image:: table_images/011_axi4_bridge_slave_read_interface_port_descriptions.png
    :align: center



.. _config_axi4-lite_memory_mapped_write_master_interface_port_descriptions:

Config AXI4-Lite Memory Mapped Write Master Interface Port Descriptions
-----------------------------------------------------------------------
.. image:: table_images/012_config_axi4-lite_memory_mapped_write_master_interface_port_descriptions.png
    :align: center



.. _config_axi4-lite_memory_mapped_read_master_interface_port_descriptions:

Config AXI4-Lite Memory Mapped Read Master Interface Port Descriptions
----------------------------------------------------------------------
.. image:: table_images/013_config_axi4-lite_memory_mapped_read_master_interface_port_descriptions.png
    :align: center



.. _config_axi4-lite_memory_mapped_write_slave_interface_signals:

Config AXI4-Lite Memory Mapped Write Slave Interface Signals
------------------------------------------------------------
.. image:: table_images/014_config_axi4-lite_memory_mapped_write_slave_interface_signals.png
    :align: center



.. _config_axi4-lite_memory_mapped_read_slave_interface_signals:

Config AXI4-Lite Memory Mapped Read Slave Interface Signals
-----------------------------------------------------------
.. image:: table_images/015_config_axi4-lite_memory_mapped_read_slave_interface_signals.png
    :align: center



.. _axi4_memory_mapped_dma_read_address_interface_signals:

AXI4 Memory Mapped DMA Read Address Interface Signals
-----------------------------------------------------
.. image:: table_images/016_axi4_memory_mapped_dma_read_address_interface_signals.png
    :align: center



.. _axi4_memory_mapped_dma_read_interface_signals:

AXI4 Memory Mapped DMA Read Interface Signals
---------------------------------------------
.. image:: table_images/017_axi4_memory_mapped_dma_read_interface_signals.png
    :align: center



.. _axi4_memory_mapped_dma_write_address_interface_signals:

AXI4 Memory Mapped DMA Write Address Interface Signals
------------------------------------------------------
.. image:: table_images/018_axi4_memory_mapped_dma_write_address_interface_signals.png
    :align: center



.. _axi4_memory_mapped_dma_write_interface_signals:

AXI4 Memory Mapped DMA Write Interface Signals
----------------------------------------------
.. image:: table_images/019_axi4_memory_mapped_dma_write_interface_signals.png
    :align: center



.. _axi4_memory_mapped_dma_write_response_interface_signals:

AXI4 Memory Mapped DMA Write Response Interface Signals
-------------------------------------------------------
.. image:: table_images/020_axi4_memory_mapped_dma_write_response_interface_signals.png
    :align: center



.. _axi4-stream_h2c_port_descriptions:

AXI4-Stream H2C Port Descriptions
---------------------------------
.. image:: table_images/021_axi4-stream_h2c_port_descriptions.png
    :align: center



.. _axi4-stream_c2h_port_descriptions:

AXI4-Stream C2H Port Descriptions
---------------------------------
.. image:: table_images/022_axi4-stream_c2h_port_descriptions.png
    :align: center



.. _axi4-stream_c2h_completion_port_descriptions:

AXI4-Stream C2H Completion Port Descriptions
--------------------------------------------
.. image:: table_images/023_axi4-stream_c2h_completion_port_descriptions.png
    :align: center



.. _axi-st_c2h_status_port_descriptions:

AXI-ST C2H Status Port Descriptions
-----------------------------------
.. image:: table_images/024_axi-st_c2h_status_port_descriptions.png
    :align: center



.. _axi-st_c2h_write_cmp_port_descriptions:

AXI-ST C2H Write Cmp Port Descriptions
--------------------------------------
.. image:: table_images/025_axi-st_c2h_write_cmp_port_descriptions.png
    :align: center



.. _vdm_port_descriptions:

VDM Port Descriptions
---------------------
.. image:: table_images/026_vdm_port_descriptions.png
    :align: center



.. _configuration_extend_interface_port_descriptions:

Configuration Extend Interface Port Descriptions
------------------------------------------------
.. image:: table_images/027_configuration_extend_interface_port_descriptions.png
    :align: center



.. _flr_port_descriptions:

FLR Port Descriptions
---------------------
.. image:: table_images/028_flr_port_descriptions.png
    :align: center



.. _qdma_h2c-streaming_bypass_input_port_descriptions:

QDMA H2C-Streaming Bypass Input Port Descriptions
-------------------------------------------------
.. image:: table_images/029_qdma_h2c-streaming_bypass_input_port_descriptions.png
    :align: center



.. _qdma_h2c-mm_descriptor_bypass_input_port_descriptions:

QDMA H2C-MM Descriptor Bypass Input Port Descriptions
-----------------------------------------------------
.. image:: table_images/030_qdma_h2c-mm_descriptor_bypass_input_port_descriptions.png
    :align: center



.. _qdma_c2h-streaming_cache_bypass_input_port_descriptions:

QDMA C2H-Streaming Cache Bypass Input Port Descriptions
-------------------------------------------------------
.. image:: table_images/031_qdma_c2h-streaming_cache_bypass_input_port_descriptions.png
    :align: center



.. _qdma_c2h-mm_descriptor_bypass_input_port_descriptions:

QDMA C2H-MM Descriptor Bypass Input Port Descriptions
-----------------------------------------------------
.. image:: table_images/032_qdma_c2h-mm_descriptor_bypass_input_port_descriptions.png
    :align: center



.. _qdma_h2c_descriptor_bypass_output_port_descriptions:

QDMA H2C Descriptor Bypass Output Port Descriptions
---------------------------------------------------
.. image:: table_images/033_qdma_h2c_descriptor_bypass_output_port_descriptions.png
    :align: center



.. _qdma_c2h_descriptor_bypass_output_port_descriptions:

QDMA C2H Descriptor Bypass Output Port Descriptions
---------------------------------------------------
.. image:: table_images/034_qdma_c2h_descriptor_bypass_output_port_descriptions.png
    :align: center



.. _qdma_descriptor_credit_input_port_descriptions:

QDMA Descriptor Credit Input Port Descriptions
----------------------------------------------
.. image:: table_images/035_qdma_descriptor_credit_input_port_descriptions.png
    :align: center



.. _qdma_tm_credit_output_port_descriptions:

QDMA TM Credit Output Port Descriptions
---------------------------------------
.. image:: table_images/036_qdma_tm_credit_output_port_descriptions.png
    :align: center



.. _user_interrupts_port_descriptions:

User Interrupts Port Descriptions
---------------------------------
.. image:: table_images/037_user_interrupts_port_descriptions.png
    :align: center



.. _queue_status_ports:

Queue Status Ports
------------------
.. image:: table_images/038_queue_status_ports.png
    :align: center



.. _queue_status_data:

Queue status data
-----------------
.. image:: table_images/039_queue_status_data.png
    :align: center


